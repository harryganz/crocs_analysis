require(proxyC)
require(testthat)
test_check("proxyC")
