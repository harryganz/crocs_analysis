# v0.1.5

## New feature

- Add the dorp0 argument

## Bug fix

- The digit argument is now passed to dist()

# v0.1.4

## New feature

- Add rowSds(), colSds(), rowZeros() and colZeros()

# v0.1.3

## Bug fix

- No longer assumes symmetry of resulting matrix when x != y (#3)

## New feature

- Add the digits argument to correct rounding errors in C++ (#5)
